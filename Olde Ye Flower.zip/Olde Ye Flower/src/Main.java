import BasicIO.*;
public class Main {
    public ASCIIDisplayer display;

    public static void main(String[] args){
        //display = new ASCIIDisplayer();
        //display.writeLine("");
        System.out.println(" __   __U _____ u       U  ___ u   _      ____  U _____ u      _____    _       U  ___ u            U _____ u   ____          ____     _   _     U  ___ u  ____     ____   U _____ u \n");
    }
}
